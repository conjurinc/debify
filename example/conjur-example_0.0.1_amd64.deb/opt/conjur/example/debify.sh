#!/bin/bash -e

echo "running debify.sh"
